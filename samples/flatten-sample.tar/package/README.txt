This file starts inside package/ in the archive.

With flattening enabled, it should extract to:

out/README.txt

With flattening disabled, it should extract to:

out/package/README.txt
