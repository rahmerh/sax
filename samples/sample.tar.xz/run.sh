#!/bin/sh
printf "sample executable\n"
